
primeSpamEsWrapper(document.getElementById('numberSlotTime').value)