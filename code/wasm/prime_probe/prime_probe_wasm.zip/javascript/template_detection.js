// run gcd op in while
// process interessting cache sets for shift op first
// mp_gcd operation needs around 800 000 cycles, therefore we need at least 2000
// slots
workerWasm1.postMessage(['buildEs', 0]);