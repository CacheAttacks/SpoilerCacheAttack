/* src/config.h.  Generated from config.h.in by configure.  */
#define PACKAGE_VERSION "0.02"

#define HAVE_DWARF 1
#define HAVE_LIBDWARF_H 1
/* #undef HAVE_LIBDWARF_LIBDWARF_H */
#define HAVE_BFD_H 1
#define HAVE_SYS_PRCTL_H 1
#define HAVE_SCHED_H 1
#define HAVE_MMAP64 1

#define HAVE_SCHED_SETAFFINITY 1

#define HAVE_SYMBOLS 1

#define WASM